-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: i7c208.p.ssafy.io    Database: s07p11c208
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `dms`
--

DROP TABLE IF EXISTS `dms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dms` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `from_user_id` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `to_user_id` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `content` varchar(200) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `image` longblob,
  `is_read` tinyint(1) DEFAULT '0',
  `time` datetime NOT NULL,
  PRIMARY KEY (`idx`),
  KEY `dms_FK` (`from_user_id`),
  KEY `dms_FK_1` (`to_user_id`),
  CONSTRAINT `dms_FK` FOREIGN KEY (`from_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `dms_FK_1` FOREIGN KEY (`to_user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=685 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dms`
--

LOCK TABLES `dms` WRITE;
/*!40000 ALTER TABLE `dms` DISABLE KEYS */;
INSERT INTO `dms` VALUES (536,'kakao2355918948','test5','댓글보고 연락드려요',NULL,1,'2022-08-15 22:31:48'),(537,'kakao2355918948','test5','개발자 지망생이시라구요?',NULL,1,'2022-08-15 22:31:52'),(538,'test5','kakao2355918948','네',NULL,1,'2022-08-15 22:31:59'),(539,'test5','kakao2355918948','현재 개발자 지망생인데',NULL,1,'2022-08-15 22:32:04'),(540,'test5','kakao2355918948','돈이 없어서. ',NULL,1,'2022-08-15 22:32:06'),(541,'test5','kakao2355918948','키보드를 못사고 있어용 ㅜ.ㅜ',NULL,1,'2022-08-15 22:32:12'),(542,'kakao2355918948','test5','좋습니다',NULL,1,'2022-08-15 22:32:16'),(543,'kakao2355918948','test5','거래하시죠',NULL,1,'2022-08-15 22:32:17'),(544,'test5','kakao2355918948','오!',NULL,1,'2022-08-15 22:32:24'),(545,'test5','kakao2355918948','여기서 추천해준',NULL,1,'2022-08-15 22:32:27'),(546,'test5','kakao2355918948','중간 위치에서 만날까요!!??',NULL,1,'2022-08-15 22:32:32'),(547,'kakao2355918948','test5','넵! 그럼 6시 30분에 뵙도록 하죠.',NULL,1,'2022-08-15 22:32:43'),(548,'test5','kakao2355918948','네엡 좋습니다!,!ㅎㅎ ㅎㅎ',NULL,1,'2022-08-15 22:32:52'),(550,'test','test11','test',NULL,1,'2022-08-16 10:38:27'),(551,'test','test11','test',NULL,1,'2022-08-16 10:39:09'),(552,'test','test11','test',NULL,1,'2022-08-16 10:59:38'),(553,'test','test11','test',NULL,1,'2022-08-16 11:00:37'),(554,'test','test11','test',NULL,1,'2022-08-16 11:02:02'),(555,'test','test11','test',NULL,1,'2022-08-16 11:02:50'),(556,'test','test11','test',NULL,1,'2022-08-16 11:03:07'),(557,'test','test11','test',NULL,1,'2022-08-16 11:11:37'),(558,'test','test11','test',NULL,1,'2022-08-16 11:16:22'),(559,'test','test11','test',NULL,1,'2022-08-16 11:17:25'),(560,'test','test11','test',NULL,1,'2022-08-16 11:24:15'),(561,'test','test11','test',NULL,1,'2022-08-16 11:28:45'),(562,'test','test11','test',NULL,1,'2022-08-16 11:29:10'),(563,'test','test11','test',NULL,1,'2022-08-16 11:30:29'),(564,'test','test11','test',NULL,1,'2022-08-16 11:30:43'),(565,'test','test11','test',NULL,1,'2022-08-16 11:31:26'),(566,'test','test11','test',NULL,1,'2022-08-16 11:32:32'),(567,'test','test11','test',NULL,1,'2022-08-16 11:33:09'),(568,'test','test11','test',NULL,1,'2022-08-16 11:33:41'),(569,'test','test11','test',NULL,1,'2022-08-16 11:33:57'),(570,'test','test11','test',NULL,1,'2022-08-16 11:35:58'),(571,'test','test11','test',NULL,1,'2022-08-16 11:36:21'),(572,'test','test11','test',NULL,1,'2022-08-16 11:36:43'),(573,'test','test11','test',NULL,1,'2022-08-16 11:36:55'),(574,'test','test11','test',NULL,1,'2022-08-16 11:41:15'),(575,'test','test11','test',NULL,1,'2022-08-16 11:41:24'),(576,'test','test11','test',NULL,1,'2022-08-16 11:41:43'),(577,'test','test11','test',NULL,1,'2022-08-16 11:43:03'),(578,'test','test11','test',NULL,1,'2022-08-16 11:43:50'),(579,'test','test11','test',NULL,1,'2022-08-16 11:44:30'),(580,'test','test11','test',NULL,1,'2022-08-16 11:46:32'),(581,'test','test11','test',NULL,1,'2022-08-16 11:47:32'),(582,'test','test11','test',NULL,1,'2022-08-16 11:48:05'),(583,'test','test11','test',NULL,1,'2022-08-16 11:48:42'),(584,'test','test11','test',NULL,1,'2022-08-16 11:50:10'),(585,'test','test11','test',NULL,1,'2022-08-16 11:51:36'),(586,'test','test11','test',NULL,1,'2022-08-16 11:52:02'),(587,'test','test11','test',NULL,1,'2022-08-16 11:53:04'),(588,'test','test11','test',NULL,1,'2022-08-16 11:53:27'),(589,'test','test11','test',NULL,1,'2022-08-16 11:56:49'),(590,'test','test11','test',NULL,1,'2022-08-16 11:58:08'),(591,'test','test11','test',NULL,1,'2022-08-16 11:58:19'),(592,'test','test11','test',NULL,1,'2022-08-16 12:40:17'),(593,'test','test11','test',NULL,1,'2022-08-16 12:40:56'),(594,'test','test11','test',NULL,1,'2022-08-16 12:49:11'),(595,'test','test11','test',NULL,1,'2022-08-16 12:49:48'),(596,'test','test11','test',NULL,1,'2022-08-16 12:50:18'),(597,'test','test11','test',NULL,1,'2022-08-16 12:50:26'),(598,'test','test11','test',NULL,1,'2022-08-16 12:52:19'),(599,'test','test11','test',NULL,1,'2022-08-16 12:54:00'),(600,'test','test11','test',NULL,1,'2022-08-16 12:54:34'),(601,'test','test11','test',NULL,1,'2022-08-16 12:56:44'),(602,'test','test11','test',NULL,1,'2022-08-16 12:58:02'),(603,'test','test11','test',NULL,1,'2022-08-16 12:58:43'),(604,'test','test11','test',NULL,1,'2022-08-16 13:02:31'),(605,'test','test11','test',NULL,1,'2022-08-16 13:04:22'),(606,'test','test11','test',NULL,1,'2022-08-16 13:07:28'),(607,'test','test11','test',NULL,1,'2022-08-16 13:07:47'),(608,'test','test11','test',NULL,1,'2022-08-16 13:08:16'),(609,'test','test11','test',NULL,1,'2022-08-16 13:08:29'),(610,'test','test11','test',NULL,1,'2022-08-16 13:09:14'),(611,'test','test11','test',NULL,1,'2022-08-16 13:11:56'),(612,'test','test11','test',NULL,1,'2022-08-16 13:12:22'),(613,'test','test11','test',NULL,1,'2022-08-16 13:12:33'),(614,'test','test11','test',NULL,1,'2022-08-16 13:13:19'),(615,'test','test11','test',NULL,1,'2022-08-16 13:13:55'),(616,'test','test11','test',NULL,1,'2022-08-16 13:14:21'),(617,'test','test11','test',NULL,1,'2022-08-16 13:14:48'),(618,'test','test11','test',NULL,1,'2022-08-16 13:15:48'),(619,'test','test11','test',NULL,1,'2022-08-16 13:16:04'),(620,'test','test11','test',NULL,1,'2022-08-16 13:17:21'),(621,'test','test11','test',NULL,1,'2022-08-16 13:18:22'),(622,'test','test11','test',NULL,0,'2022-08-16 13:29:56'),(623,'test','test11','test',NULL,0,'2022-08-16 13:32:56'),(624,'test','test11','test',NULL,0,'2022-08-16 13:35:40'),(625,'test','test11','test',NULL,0,'2022-08-16 13:38:30'),(626,'test','test11','test',NULL,0,'2022-08-16 13:39:34'),(627,'test','test11','test',NULL,0,'2022-08-16 13:40:19'),(628,'test','test11','test',NULL,0,'2022-08-16 13:42:03'),(629,'test','test11','test',NULL,0,'2022-08-16 13:43:32'),(630,'test','test11','test',NULL,0,'2022-08-16 13:44:38'),(631,'test','test11','test',NULL,0,'2022-08-16 13:45:25'),(632,'test','test11','test',NULL,0,'2022-08-16 13:46:51'),(633,'test','test11','test',NULL,0,'2022-08-16 13:47:04'),(634,'test','test11','test',NULL,0,'2022-08-16 13:48:12'),(635,'test','test11','test',NULL,0,'2022-08-16 13:49:04'),(636,'test','test11','test',NULL,0,'2022-08-16 13:49:52'),(637,'test','test11','test',NULL,0,'2022-08-16 13:50:12'),(638,'test','test11','test',NULL,0,'2022-08-16 13:50:53'),(639,'test','test11','test',NULL,0,'2022-08-16 13:51:34'),(640,'test','test11','test',NULL,0,'2022-08-16 14:03:16'),(641,'test','test11','test',NULL,0,'2022-08-16 14:32:36'),(642,'test','test11','test',NULL,0,'2022-08-16 14:33:24'),(643,'test','test11','test',NULL,0,'2022-08-16 14:50:51'),(644,'test','test11','test',NULL,0,'2022-08-16 14:51:43'),(645,'test','test11','test',NULL,0,'2022-08-16 15:02:31'),(646,'test','test11','test',NULL,0,'2022-08-16 15:04:00'),(647,'test','test11','test',NULL,0,'2022-08-16 15:04:44'),(648,'test','test11','test',NULL,0,'2022-08-16 15:05:22'),(649,'test','test11','test',NULL,0,'2022-08-16 15:05:44'),(650,'test','test11','test',NULL,0,'2022-08-16 15:09:08'),(651,'test','test11','test',NULL,0,'2022-08-16 15:10:53'),(652,'test','test11','test',NULL,0,'2022-08-16 15:12:55'),(653,'test','test11','test',NULL,0,'2022-08-16 15:14:00'),(654,'test','test11','test',NULL,0,'2022-08-16 15:15:14'),(655,'test','test11','test',NULL,0,'2022-08-16 15:15:39'),(656,'test','test11','test',NULL,0,'2022-08-16 15:25:52'),(657,'test','test11','test',NULL,0,'2022-08-16 15:26:45'),(658,'test','test11','test',NULL,0,'2022-08-16 15:27:13'),(659,'test','test11','test',NULL,0,'2022-08-16 15:27:32'),(660,'test','test11','test',NULL,0,'2022-08-16 15:28:37'),(661,'test','test11','test',NULL,0,'2022-08-16 15:30:27'),(662,'test','test11','test',NULL,0,'2022-08-16 15:31:31'),(663,'test','test11','test',NULL,0,'2022-08-16 15:32:42'),(664,'test','test11','test',NULL,0,'2022-08-16 15:33:11'),(665,'test','test11','test',NULL,0,'2022-08-16 15:34:22'),(666,'test','test11','test',NULL,0,'2022-08-16 15:39:09'),(667,'test','test11','test',NULL,0,'2022-08-16 15:39:55'),(668,'test','test11','test',NULL,0,'2022-08-16 15:40:22'),(669,'test','test11','test',NULL,0,'2022-08-16 15:40:38'),(670,'test','test11','test',NULL,0,'2022-08-16 15:50:31'),(671,'test','test11','test',NULL,0,'2022-08-16 15:50:46'),(672,'test','test11','test',NULL,0,'2022-08-16 15:53:48'),(673,'test','test11','test',NULL,0,'2022-08-16 15:54:52'),(674,'test','test11','test',NULL,0,'2022-08-16 15:55:34'),(675,'test','test11','test',NULL,0,'2022-08-16 15:56:47'),(676,'test','test11','test',NULL,0,'2022-08-16 15:58:30'),(677,'test','test11','test',NULL,0,'2022-08-16 16:03:42'),(678,'test','test11','test',NULL,0,'2022-08-16 16:04:47'),(679,'test','test11','test',NULL,0,'2022-08-16 16:06:29'),(680,'test','test11','test',NULL,0,'2022-08-16 16:08:02'),(681,'test','test11','test',NULL,0,'2022-08-16 16:09:17'),(682,'test','test11','test',NULL,0,'2022-08-16 16:11:09'),(683,'test','test11','test',NULL,0,'2022-08-16 16:11:29'),(684,'aa981204@naver.com','kakao2385859929','안녕하세요',NULL,0,'2022-08-16 17:51:23');
/*!40000 ALTER TABLE `dms` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-16 22:40:16
