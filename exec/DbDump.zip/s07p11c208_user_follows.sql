-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: i7c208.p.ssafy.io    Database: s07p11c208
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user_follows`
--

DROP TABLE IF EXISTS `user_follows`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_follows` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `follow_nickname` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `user_nickname` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `user_id` varchar(30) COLLATE utf8mb3_unicode_ci NOT NULL,
  `follow_id` varchar(30) COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`idx`),
  KEY `user_follows_FK` (`user_id`),
  KEY `user_follows_FK_1` (`follow_id`),
  CONSTRAINT `user_follows_FK` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_follows_FK_1` FOREIGN KEY (`follow_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=447 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_follows`
--

LOCK TABLES `user_follows` WRITE;
/*!40000 ALTER TABLE `user_follows` DISABLE KEYS */;
INSERT INTO `user_follows` VALUES (247,'라이언조아','k23559','2022-08-15 09:49:49','kakao2355918948','test6'),(253,'잔망루피','k23559','2022-08-15 11:34:29','kakao2355918948','test5'),(254,'잔망루피','k23477','2022-08-15 11:34:45','kakao2347798773','test5'),(255,'나는야 최강','k23559','2022-08-15 11:35:33','kakao2355918948','test1'),(259,'라이언조아','k23802','2022-08-15 15:10:11','kakao2380210675','test6'),(261,'잔망루피','test','2022-08-15 17:52:23','test','test5'),(262,'진진자라','자취마스터123','2022-08-15 18:06:44','test3','aa981204@naver.com'),(266,'자취초보인데용','test','2022-08-15 20:19:24','test','test8'),(270,'잔망루피','구글진호123','2022-08-15 21:14:22','google116931803644942448758','test5'),(271,'라이언조아','ㅂㅂㅂ','2022-08-15 21:14:23','google103917661567209305041','test6'),(272,'진진자라','자취를알려줘','2022-08-15 21:17:28','test7','aa981204@naver.com'),(273,'진진자라','dkdkd','2022-08-15 21:17:37','google105681535076154417388','aa981204@naver.com'),(274,'잔망루피','라이언조아','2022-08-15 21:20:02','test6','test5'),(276,'나는야 최강','dkdkd','2022-08-15 21:22:46','google105681535076154417388','test1'),(282,'라이언조아','aksjdhgf','2022-08-15 23:14:11','rdg9074@naver.com','test6'),(285,'코딩 마스터','자취초보인데용','2022-08-16 00:51:17','test8','kakao2355918948'),(286,'진진자라','지노짱','2022-08-16 00:53:41','kakao2347798773','aa981204@naver.com'),(287,'잔망루피','daz','2022-08-16 00:54:01','google105681535076154417388','test5'),(288,'자취마스터123','daz','2022-08-16 00:54:05','google105681535076154417388','test3'),(290,'지노짱','안경닦이','2022-08-16 10:07:35','kakao2380210675','kakao2347798773'),(292,'도라에몽','안경닦이','2022-08-16 10:08:50','kakao2380210675','kakao2381932536'),(303,'코딩 마스터','test11','2022-08-16 10:33:57','test11','kakao2355918948'),(439,'우주최강귀염둥이','진진자라','2022-08-16 18:03:04','aa981204@naver.com','kakao2385859929'),(446,'코딩 마스터','test','2022-08-16 22:39:43','test','kakao2355918948');
/*!40000 ALTER TABLE `user_follows` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-16 22:40:14
