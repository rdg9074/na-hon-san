-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: i7c208.p.ssafy.io    Database: s07p11c208
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user_category`
--

DROP TABLE IF EXISTS `user_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_category` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `category` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  PRIMARY KEY (`idx`),
  KEY `user_category_FK` (`user_id`),
  CONSTRAINT `user_category_FK` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=358 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_category`
--

LOCK TABLES `user_category` WRITE;
/*!40000 ALTER TABLE `user_category` DISABLE KEYS */;
INSERT INTO `user_category` VALUES (213,'test1','가전디지털'),(214,'kakao2355918948','주방용품'),(215,'kakao2355918948','생활용품'),(216,'kakao2355918948','가전디지털'),(238,'test7','A'),(239,'test7','B'),(240,'test6','A'),(241,'test6','B'),(252,'kakao2380210675','기타'),(253,'kakao2380210675','주방용품'),(254,'kakao2380210675','식품'),(255,'kakao2380210675','의류'),(256,'kakao2380210675','홈인테리어'),(257,'kakao2380210675','가전디지털'),(258,'kakao2380210675','취미용품'),(259,'kakao2380210675','생활용품'),(276,'google101918676652174580537','식품'),(277,'google101918676652174580537','가전디지털'),(278,'google103917661567209305041','취미용품'),(279,'google103917661567209305041','주방용품'),(280,'google103917661567209305041','의류'),(281,'google103917661567209305041','가전디지털'),(282,'google103917661567209305041','식품'),(283,'google103917661567209305041','홈인테리어'),(284,'google103917661567209305041','기타'),(285,'google103917661567209305041','생활용품'),(306,'test8','의류'),(307,'test8','홈인테리어'),(308,'test8','가전디지털'),(309,'test8','식품'),(310,'test8','주방용품'),(311,'test8','취미용품'),(312,'test8','기타'),(313,'test8','생활용품'),(314,'kakao2380224874','식품'),(315,'kakao2380224874','가전디지털'),(316,'kakao2380224874','취미용품'),(317,'test3','가전디지털'),(318,'google100132514925826896780','의류'),(319,'google100132514925826896780','식품'),(320,'google100132514925826896780','가전디지털'),(321,'test5','A'),(322,'test5','B'),(323,'test5','가전디지털'),(324,'test5','홈인테리어'),(325,'test5','식품'),(326,'test5','의류'),(327,'test5','주방용품'),(328,'test5','취미용품'),(329,'test5','기타'),(330,'test5','생활용품'),(334,'rdg9074@naver.com','의류'),(335,'rdg9074@naver.com','가전디지털'),(336,'rdg9074@naver.com','주방용품'),(337,'rdg9074@naver.com','취미용품'),(338,'rdg9074@naver.com','식품'),(339,'rdg9074@naver.com','홈인테리어'),(340,'rdg9074@naver.com','생활용품'),(341,'kakao2347798773','의류'),(342,'kakao2381932536','의류'),(343,'kakao2381932536','홈인테리어'),(344,'google105681535076154417388','의류'),(345,'google105681535076154417388','주방용품'),(346,'google105681535076154417388','가전디지털'),(347,'google105681535076154417388','생활용품'),(350,'aa981204@naver.com','식품'),(351,'aa981204@naver.com','생활용품'),(352,'aa981204@naver.com','취미용품'),(353,'aa981204@naver.com','의류'),(354,'aa981204@naver.com','주방용품'),(355,'aa981204@naver.com','홈인테리어'),(356,'aa981204@naver.com','가전디지털'),(357,'aa981204@naver.com','기타');
/*!40000 ALTER TABLE `user_category` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-16 22:40:15
