-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: i7c208.p.ssafy.io    Database: s07p11c208
-- ------------------------------------------------------
-- Server version	8.0.30-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `notices`
--

DROP TABLE IF EXISTS `notices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notices` (
  `idx` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `notice_type` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL COMMENT 'ìë¦¼íì(comment,reply,follw,like)',
  `isread` tinyint(1) NOT NULL DEFAULT '0',
  `from_user_id` varchar(30) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci NOT NULL,
  `post_type` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_ci DEFAULT NULL COMMENT 'ê²ìê¸íì(deal,tip)',
  `post_idx` int DEFAULT NULL,
  `time` datetime NOT NULL,
  `comment_idx` int DEFAULT '0',
  `comment_up_idx` int DEFAULT '0',
  PRIMARY KEY (`idx`),
  KEY `notices_FK` (`user_id`),
  CONSTRAINT `notices_FK` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=769 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notices`
--

LOCK TABLES `notices` WRITE;
/*!40000 ALTER TABLE `notices` DISABLE KEYS */;
INSERT INTO `notices` VALUES (486,'kakao2355918948','like',0,'aa981204@naver.com','deal',121,'2022-08-14 12:00:50',0,0),(487,'test1','like',0,'test3','deal',120,'2022-08-14 12:00:58',0,0),(488,'kakao2355918948','like',0,'test3','deal',121,'2022-08-14 12:01:01',0,0),(490,'aa981204@naver.com','like',1,'test8','deal',122,'2022-08-14 12:01:23',0,0),(491,'kakao2355918948','comment',0,'aa981204@naver.com','deal',121,'2022-08-14 12:02:18',108,0),(492,'test1','like',0,'aa981204@naver.com','deal',120,'2022-08-14 12:02:41',0,0),(493,'test1','comment',0,'test8','deal',120,'2022-08-14 12:04:46',110,0),(494,'aa981204@naver.com','comment',1,'test8','deal',122,'2022-08-14 12:05:27',111,0),(495,'test1','comment',0,'aa981204@naver.com','deal',120,'2022-08-14 12:06:58',112,0),(499,'test3','like',1,'test6','tip',210,'2022-08-14 16:50:06',0,0),(514,'test1','comment',0,'kakao2355918948','deal',120,'2022-08-15 11:35:12',119,0),(516,'test1','follow',0,'kakao2355918948',NULL,NULL,'2022-08-15 11:35:33',0,0),(517,'test1','like',0,'kakao2355918948','deal',120,'2022-08-15 11:35:34',0,0),(518,'aa981204@naver.com','comment',0,'kakao2347798773','deal',122,'2022-08-15 11:58:18',125,0),(519,'aa981204@naver.com','comment',1,'kakao2347798773','deal',122,'2022-08-15 11:58:28',126,0),(529,'test1','comment',0,'test9','deal',120,'2022-08-15 13:30:47',133,0),(535,'aa981204@naver.com','like',0,'kakao2385859929','tip',207,'2022-08-15 17:42:20',0,0),(536,'aa981204@naver.com','like',0,'test3','tip',207,'2022-08-15 17:43:22',0,0),(538,'test5','follow',1,'test',NULL,NULL,'2022-08-15 17:52:23',0,0),(539,'aa981204@naver.com','follow',0,'test3',NULL,NULL,'2022-08-15 18:06:44',0,0),(546,'aa981204@naver.com','like',0,'test8','tip',207,'2022-08-15 21:06:30',0,0),(547,'aa981204@naver.com','comment',0,'test8','tip',207,'2022-08-15 21:06:35',228,0),(548,'aa981204@naver.com','like',0,'kakao2355918948','deal',122,'2022-08-15 21:12:20',0,0),(549,'test5','like',1,'aa981204@naver.com','tip',212,'2022-08-15 21:12:51',0,0),(556,'test5','follow',1,'google116931803644942448758',NULL,NULL,'2022-08-15 21:14:22',0,0),(558,'aa981204@naver.com','follow',0,'test7',NULL,NULL,'2022-08-15 21:17:28',0,0),(559,'aa981204@naver.com','follow',0,'google105681535076154417388',NULL,NULL,'2022-08-15 21:17:37',0,0),(560,'aa981204@naver.com','like',1,'test7','deal',122,'2022-08-15 21:17:38',0,0),(561,'test5','follow',1,'test6',NULL,NULL,'2022-08-15 21:20:02',0,0),(563,'test5','like',1,'test8','tip',212,'2022-08-15 21:20:24',0,0),(565,'test1','like',0,'google105681535076154417388','deal',120,'2022-08-15 21:22:43',0,0),(566,'test1','follow',0,'google105681535076154417388',NULL,NULL,'2022-08-15 21:22:46',0,0),(568,'kakao2355918948','comment',0,'kakao2380224874','deal',121,'2022-08-15 21:27:41',134,0),(570,'test5','comment',1,'test8','deal',128,'2022-08-15 21:28:08',135,0),(573,'aa981204@naver.com','comment',0,'google100132514925826896780','tip',216,'2022-08-15 21:35:54',235,0),(575,'aa981204@naver.com','like',0,'google100132514925826896780','tip',207,'2022-08-15 21:38:35',0,0),(577,'aa981204@naver.com','like',1,'google100132514925826896780','tip',216,'2022-08-15 21:39:17',0,0),(578,'aa981204@naver.com','like',1,'kakao2380224874','tip',207,'2022-08-15 21:42:01',0,0),(579,'test5','comment',1,'aa981204@naver.com','tip',212,'2022-08-15 21:47:59',237,0),(580,'test3','like',0,'aa981204@naver.com','tip',210,'2022-08-15 21:48:38',0,0),(582,'aa981204@naver.com','like',0,'test5','tip',216,'2022-08-15 21:57:45',0,0),(583,'test6','follow',0,'rdg9074@naver.com',NULL,NULL,'2022-08-15 23:14:11',0,0),(596,'kakao2355918948','like',0,'test8','deal',133,'2022-08-16 00:51:17',0,0),(597,'kakao2355918948','follow',0,'test8',NULL,NULL,'2022-08-16 00:51:17',0,0),(598,'aa981204@naver.com','follow',0,'kakao2347798773',NULL,NULL,'2022-08-16 00:53:41',0,0),(599,'test5','follow',0,'google105681535076154417388',NULL,NULL,'2022-08-16 00:54:01',0,0),(600,'test3','follow',0,'google105681535076154417388',NULL,NULL,'2022-08-16 00:54:05',0,0),(602,'kakao2347798773','follow',0,'kakao2380210675',NULL,NULL,'2022-08-16 10:07:35',0,0),(604,'kakao2381932536','follow',0,'kakao2380210675',NULL,NULL,'2022-08-16 10:08:50',0,0),(615,'kakao2355918948','follow',0,'test11',NULL,NULL,'2022-08-16 10:33:57',0,0),(750,'test8','reply',0,'aa981204@naver.com','tip',207,'2022-08-16 17:50:58',248,228),(753,'kakao2385859929','follow',0,'aa981204@naver.com',NULL,NULL,'2022-08-16 18:03:04',0,0),(754,'kakao2385859929','like',0,'aa981204@naver.com','tip',219,'2022-08-16 18:03:05',0,0),(767,'kakao2355918948','follow',0,'test',NULL,NULL,'2022-08-16 22:39:43',0,0);
/*!40000 ALTER TABLE `notices` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-16 22:40:14
